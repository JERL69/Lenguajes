# algoritmo.py
# Implementación de Primeros, Siguientes y Predicciones en Python
# con control de recursión infinita

def leer_gramatica(nombre_archivo):
    reglas = {}
    with open(nombre_archivo, "r", encoding="utf-8") as archivo:
        for linea in archivo:
            linea = linea.strip()
            if not linea or "→" not in linea:
                continue
            izquierda, derechos = linea.split("→")
            izquierda = izquierda.strip()
            for prod in derechos.split("|"):
                prod = prod.strip().split()
                reglas.setdefault(izquierda, []).append(prod)
    return reglas

def calcular_primeros(reglas):
    primeros = {no_term: set() for no_term in reglas}

    def primeros_de(simbolos, visitados=set()):
        if not simbolos:
            return {"ε"}
        primero = simbolos[0]
        # Si es terminal
        if primero not in reglas:
            return {primero}
        # Si es no terminal y ya se está visitando, evitar ciclo
        if primero in visitados:
            return set()
        resultado = set()
        for produccion in reglas[primero]:
            sub_primeros = primeros_de(produccion, visitados | {primero})
            resultado |= (sub_primeros - {"ε"})
            if "ε" in sub_primeros:
                resultado |= primeros_de(simbolos[1:], visitados)
        return resultado

    cambio = True
    while cambio:
        cambio = False
        for no_term in reglas:
            antes = len(primeros[no_term])
            for prod in reglas[no_term]:
                primeros[no_term] |= primeros_de(prod)
            if len(primeros[no_term]) > antes:
                cambio = True
    return primeros

def calcular_siguientes(reglas, primeros):
    siguientes = {no_term: set() for no_term in reglas}
    simbolo_inicial = list(reglas.keys())[0]
    siguientes[simbolo_inicial].add("$")

    cambio = True
    while cambio:
        cambio = False
        for izquierda in reglas:
            for prod in reglas[izquierda]:
                for i, simbolo in enumerate(prod):
                    if simbolo in reglas:  # no terminal
                        resto = prod[i+1:]
                        if resto:
                            primeros_resto = calcular_primeros_de_cadena(resto, primeros)
                            nuevos = primeros_resto - {"ε"}
                            if not nuevos.issubset(siguientes[simbolo]):
                                siguientes[simbolo] |= nuevos
                                cambio = True
                            if "ε" in primeros_resto:
                                if not siguientes[izquierda].issubset(siguientes[simbolo]):
                                    siguientes[simbolo] |= siguientes[izquierda]
                                    cambio = True
                        else:
                            if not siguientes[izquierda].issubset(siguientes[simbolo]):
                                siguientes[simbolo] |= siguientes[izquierda]
                                cambio = True
    return siguientes

def calcular_primeros_de_cadena(cadena, primeros):
    if not cadena:
        return {"ε"}
    primero = cadena[0]
    if primero not in primeros:
        return {primero}
    resultado = set()
    for simbolo in cadena:
        if simbolo not in primeros:
            resultado.add(simbolo)
            return resultado
        resultado |= (primeros[simbolo] - {"ε"})
        if "ε" not in primeros[simbolo]:
            return resultado
    resultado.add("ε")
    return resultado

def calcular_predicciones(reglas, primeros, siguientes):
    predicciones = []
    for izquierda in reglas:
        for prod in reglas[izquierda]:
            conj_pred = calcular_primeros_de_cadena(prod, primeros)
            if "ε" in conj_pred:
                conj_pred.remove("ε")
                conj_pred |= siguientes[izquierda]
            predicciones.append((izquierda, prod, conj_pred))
    return predicciones

def imprimir_resultados(primeros, siguientes, predicciones):
    print("Conjunto de Primeros")
    for no_term in primeros:
        print(f"Primeros({no_term}) = {sorted(list(primeros[no_term]))}")

    print("\nConjunto de Siguientes")
    for no_term in siguientes:
        print(f"Siguientes({no_term}) = {sorted(list(siguientes[no_term]))}")

    print("\nConjunto de Predicciones")
    for izq, prod, pred in predicciones:
        regla = " ".join(prod)
        print(f"Pred({izq} → {regla}) = {sorted(list(pred))}")

# --------------------------
# PROGRAMA PRINCIPAL
# --------------------------
if __name__ == "__main__":
    archivo = "gramatica.txt"
    reglas = leer_gramatica(archivo)
    primeros = calcular_primeros(reglas)
    siguientes = calcular_siguientes(reglas, primeros)
    predicciones = calcular_predicciones(reglas, primeros, siguientes)

    imprimir_resultados(primeros, siguientes, predicciones)
