from antlr4 import *
from MatLangLexer import MatLangLexer
from MatLangParser import MatLangParser

def producto_punto(A, B):
    filasA = len(A)
    columnasA = len(A[0])
    filasB = len(B)
    columnasB = len(B[0])

    if columnasA != filasB:
        raise Exception("Dimensiones incompatibles")

    C = [[0]*columnasB for _ in range(filasA)]

    for i in range(filasA):
        for j in range(columnasB):
            for k in range(columnasA):
                C[i][j] += A[i][k] * B[k][j]

    return C

class MyVisitor(ParseTreeVisitor):
    matrices = {}

    def visitMatrixDecl(self, ctx):
        nombre = ctx.ID().getText()
        M = self.visit(ctx.matrix())
        self.matrices[nombre] = M
        print(f"Declarada matriz {nombre}: {M}")

    def visitMatrix(self, ctx):
        return self.visit(ctx.rowList())

    def visitRowList(self, ctx):
        return [self.visit(r) for r in ctx.row()]

    def visitRow(self, ctx):
        return [int(i.getText()) for i in ctx.INT()]

    def visitAssign(self, ctx):
        C = ctx.ID(0).getText()
        A = ctx.ID(1).getText()
        B = ctx.ID(2).getText()
        self.matrices[C] = producto_punto(self.matrices[A], self.matrices[B])
        print(f"{C} = {self.matrices[C]}")

def run(code):
    input_stream = InputStream(code)
    lexer = MatLangLexer(input_stream)
    tokens = CommonTokenStream(lexer)
    parser = MatLangParser(tokens)
    tree = parser.program()
    visitor = MyVisitor()
    visitor.visit(tree)

run("""
mat A = [[1,2],[3,4]];
mat B = [[2,0],[1,2]];
C = A . B;
""")
