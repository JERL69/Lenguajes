import re
import networkx as nx
import matplotlib.pyplot as plt

# -----------------------------
# Tokenización simple con regex
# -----------------------------
token_specification = [
    ('NUM',    r'\d+'),
    ('ID',     r'[a-zA-Z_]\w*'),
    ('PLUS',   r'\+'),
    ('MINUS',  r'-'),
    ('TIMES',  r'\*'),
    ('DIVIDE', r'/'),
    ('LPAREN', r'\('),
    ('RPAREN', r'\)'),
    ('SKIP',   r'[ \t]+'),
]

tok_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_specification)
get_token = re.compile(tok_regex).match

def tokenize(code):
    pos = 0
    tokens = []
    mo = get_token(code, pos)
    while mo:
        kind = mo.lastgroup
        value = mo.group()
        if kind != 'SKIP':
            tokens.append((kind, value))
        pos = mo.end()
        mo = get_token(code, pos)
    if pos != len(code):
        raise SyntaxError(f"Error en posición {pos}")
    return tokens

# -----------------------------
# Parser recursivo
# Gramática:
#   E → E (+|-) T | T
#   T → T (*|/) F | F
#   F → num | id | (E)
# -----------------------------
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else (None, None)

    def consume(self, kind=None):
        token = self.peek()
        if kind and token[0] != kind:
            raise SyntaxError(f"Esperaba {kind} y encontré {token}")
        self.pos += 1
        return token

    def parse_E(self):
        node = ("E", self.parse_T())
        while self.peek()[0] in ("PLUS", "MINUS"):
            op = self.consume()[1]
            right = self.parse_T()
            node = ("E", node, ("opsuma", op), right)
        return node

    def parse_T(self):
        node = ("T", self.parse_F())
        while self.peek()[0] in ("TIMES", "DIVIDE"):
            op = self.consume()[1]
            right = self.parse_F()
            node = ("T", node, ("opmul", op), right)
        return node

    def parse_F(self):
        kind, value = self.peek()
        if kind == "NUM":
            self.consume("NUM")
            return ("F", ("num", value))
        elif kind == "ID":
            self.consume("ID")
            return ("F", ("id", value))
        elif kind == "LPAREN":
            self.consume("LPAREN")
            expr = self.parse_E()
            self.consume("RPAREN")
            return ("F", ("pari", "("), expr, ("pard", ")"))
        else:
            raise SyntaxError(f"Token inesperado {kind}")

# -----------------------------
# Construcción del grafo
# -----------------------------
def build_graph(tree, G=None, parent=None, counter=[0]):
    if G is None:
        G = nx.DiGraph()
    node_id = counter[0]
    counter[0] += 1

    if isinstance(tree, tuple):
        label = tree[0]
        G.add_node(node_id, label=label)
        if parent is not None:
            G.add_edge(parent, node_id)

        for child in tree[1:]:
            build_graph(child, G, node_id, counter)
    else:
        G.add_node(node_id, label=str(tree))
        if parent is not None:
            G.add_edge(parent, node_id)

    return G

def draw_tree(G, expr):
    pos = nx.nx_pydot.graphviz_layout(G, prog="dot")
    labels = nx.get_node_attributes(G, "label")

    node_colors = []
    for n in G.nodes():
        if labels[n] in ["opsuma", "opmul", "num", "id", "pari", "pard"]:
            node_colors.append("lightgreen")
        else:
            node_colors.append("lightblue")

    plt.figure(figsize=(10, 6))
    plt.title(f"Árbol Sintáctico: {expr}")
    nx.draw(G, pos, labels=labels, with_labels=True,
            node_size=1500, node_color=node_colors,
            font_size=10, font_color="black")
    plt.show()

# -----------------------------
# Programa principal
# -----------------------------
if __name__ == "__main__":
    with open("gra.txt", "r") as f:
        expresiones = [line.strip() for line in f if line.strip()]

    for expr in expresiones:
        print(f"\nExpresión: {expr}")
        tokens = tokenize(expr)
        parser = Parser(tokens)
        arbol = parser.parse_E()
        G = build_graph(arbol)
        draw_tree(G, expr)

