def check_grammar(grammar_num, string):
    if grammar_num == 1:  # L(G1) = {a^n b^n | n >= 1}
        count_a = string.count('a')
        count_b = string.count('b')
        return count_a == count_b and count_a > 0 and string == 'a' * count_a + 'b' * count_b
    
    elif grammar_num == 2:  # L(G2) = {a^n b^{n+1} | n >= 0}
        count_a = string.count('a')
        count_b = string.count('b')
        return count_b == count_a + 1 and string == 'a' * count_a + 'b' * count_b
    
    elif grammar_num == 3:  # L(G3) = {a^n b^{n+1} | n > 0}
        count_a = string.count('a')
        count_b = string.count('b')
        return count_b == count_a + 1 and count_a > 0 and string == 'a' * count_a + 'b' * count_b
    
    elif grammar_num == 4:  # L(G4) = {a^n b^m | n, m >= 1, n != m}
        count_a = string.count('a')
        count_b = string.count('b')
        return count_a >= 1 and count_b >= 1 and count_a != count_b
    
    elif grammar_num == 5:  # L(G5) = {a (ab)^n b | n >= 0}
        if not string.startswith('a') or not string.endswith('b'):
            return False
        inner = string[1:-1]
        return inner == '' or all(inner[i*2:i*2+2] == 'ab' for i in range(len(inner)//2))
    
    else:
        return False

def main():
    import sys
    if len(sys.argv) != 3:
        print("Uso: python grammar_checker.py <número_gramática> <archivo.txt>")
        return
    
    grammar_num = int(sys.argv[1])
    filename = sys.argv[2]
    
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if line:
                if check_grammar(grammar_num, line):
                    print(f"'{line}': acepta")
                else:
                    print(f"'{line}': NO acepta")

if __name__ == "__main__":
    main()
