import java.util.HashMap;
import java.util.Map;

public class EvalVisitor extends LabeledExprBaseVisitor<Double> {
    Map<String, Double> memory = new HashMap<>();

    @Override
    public Double visitAssign(LabeledExprParser.AssignContext ctx) {
        String id = ctx.ID().getText();
        double value = visit(ctx.expr());
        memory.put(id, value);
        return value;
    }

    @Override
    public Double visitPrintExpr(LabeledExprParser.PrintExprContext ctx) {
        double value = visit(ctx.expr());

        if (value == Math.floor(value)) {
            System.out.println((int) value);
        } else {
            System.out.println(String.format("%.2f", value));
        }
        return 0.0;
    }

    @Override
    public Double visitInt(LabeledExprParser.IntContext ctx) {
        return Double.valueOf(ctx.INT().getText());
    }

    @Override
    public Double visitId(LabeledExprParser.IdContext ctx) {
        String id = ctx.ID().getText();
        return memory.getOrDefault(id, 0.0);
    }

    @Override
    public Double visitMulDiv(LabeledExprParser.MulDivContext ctx) {
        double left = visit(ctx.expr(0));
        double right = visit(ctx.expr(1));
        if (ctx.op.getType() == LabeledExprParser.MUL) return left * right;
        return left / right;
    }

    @Override
    public Double visitAddSub(LabeledExprParser.AddSubContext ctx) {
        double left = visit(ctx.expr(0));
        double right = visit(ctx.expr(1));
        if (ctx.op.getType() == LabeledExprParser.ADD) return left + right;
        return left - right;
    }

    @Override
    public Double visitParens(LabeledExprParser.ParensContext ctx) {
        return visit(ctx.expr());
    }

    @Override
    public Double visitPower(LabeledExprParser.PowerContext ctx) {
        double base = visit(ctx.expr(0));
        double exp = visit(ctx.expr(1));
        return Math.pow(base, exp);
    }

    @Override
    public Double visitFactorial(LabeledExprParser.FactorialContext ctx) {
        int value = visit(ctx.expr()).intValue();
        return (double) factorial(value);
    }

    private int factorial(int n) {
        if (n < 0) throw new RuntimeException("Factorial indefinido para números negativos");
        int result = 1;
        for (int i = 2; i <= n; i++) result *= i;
        return result;
    }

    // ---- FUNCIONES MATEMÁTICAS ----

    @Override
    public Double visitSinFunc(LabeledExprParser.SinFuncContext ctx) {
        double value = visit(ctx.expr());
        return Math.sin(Math.toRadians(value));
    }

    @Override
    public Double visitCosFunc(LabeledExprParser.CosFuncContext ctx) {
        double value = visit(ctx.expr());
        return Math.cos(Math.toRadians(value));
    }

    @Override
    public Double visitTanFunc(LabeledExprParser.TanFuncContext ctx) {
        double value = visit(ctx.expr());
        return Math.tan(Math.toRadians(value));
    }

    @Override
    public Double visitSqrtFunc(LabeledExprParser.SqrtFuncContext ctx) {
        double value = visit(ctx.expr());
        return Math.sqrt(value);
    }

    @Override
    public Double visitLnFunc(LabeledExprParser.LnFuncContext ctx) {
        double value = visit(ctx.expr());
        return Math.log(value); // ln = log base e
    }

    @Override
    public Double visitLogFunc(LabeledExprParser.LogFuncContext ctx) {
        double value = visit(ctx.expr());
        return Math.log10(value); // log base 10
    }
}

