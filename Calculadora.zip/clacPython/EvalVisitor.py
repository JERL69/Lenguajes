import math
from LabeledExprVisitor import LabeledExprVisitor
from LabeledExprParser import LabeledExprParser

class EvalVisitor(LabeledExprVisitor):
    def __init__(self):
        self.memory = {}

    # ---- Asignación ----
    def visitAssign(self, ctx):
        var_name = ctx.ID().getText()
        value = self.visit(ctx.expr())
        self.memory[var_name] = value
        return value

    # ---- Imprimir ----
    def visitPrintExpr(self, ctx):
        value = self.visit(ctx.expr())
        # Si es entero, mostrar sin decimales
        if value == int(value):
            print(int(value))
        else:
            # Redondea a 2 decimales si tiene parte decimal
            print(round(value, 2))
        return 0

    # ---- Enteros ----
    def visitInt(self, ctx):
        return float(ctx.INT().getText())

    # ---- Identificadores ----
    def visitId(self, ctx):
        var_name = ctx.ID().getText()
        return self.memory.get(var_name, 0.0)

    # ---- Operaciones ----
    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.type == LabeledExprParser.ADD:
            return left + right
        else:
            return left - right

    def visitMulDiv(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.type == LabeledExprParser.MUL:
            return left * right
        else:
            return left / right

    def visitPower(self, ctx):
        base = self.visit(ctx.expr(0))
        exp = self.visit(ctx.expr(1))
        return math.pow(base, exp)

    def visitFactorial(self, ctx):
        value = self.visit(ctx.expr())
        if value < 0 or value != math.floor(value):
            raise Exception("Factorial solo definido para enteros >= 0")
        return math.factorial(int(value))

    def visitParens(self, ctx):
        return self.visit(ctx.expr())

    # ---- Funciones matemáticas ----
    def visitSinFunc(self, ctx):
        value = self.visit(ctx.expr())
        return math.sin(math.radians(value))

    def visitCosFunc(self, ctx):
        value = self.visit(ctx.expr())
        return math.cos(math.radians(value))

    def visitTanFunc(self, ctx):
        value = self.visit(ctx.expr())
        return math.tan(math.radians(value))

    def visitSqrtFunc(self, ctx):
        value = self.visit(ctx.expr())
        return math.sqrt(value)

    def visitLnFunc(self, ctx):
        value = self.visit(ctx.expr())
        return math.log(value)

    def visitLogFunc(self, ctx):
        value = self.visit(ctx.expr())
        return math.log10(value)
