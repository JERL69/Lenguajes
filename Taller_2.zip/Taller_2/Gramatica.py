import sys
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

# ============================================================================
# ESTRUCTURAS DE DATOS FUNDAMENTALES
# ============================================================================

@dataclass
class Lexema:
    """Representa una unidad léxica del código fuente"""
    categoria: str
    texto: str
    fila: int
    col: int
    dato: Any = None

    def __str__(self):
        return f"Lexema[{self.categoria}]('{self.texto}' en {self.fila}:{self.col})"


class ExcepcionAnalisis(Exception):
    """Excepción base para errores de análisis"""
    pass


class FalloSintaxis(ExcepcionAnalisis):
    """Error durante análisis sintáctico"""
    def __init__(self, lex, tokens_validos=None):
        self.lexema = lex
        self.validos = tokens_validos or []
    
    def __str__(self):
        tok_mostrar = "$" if self.lexema.categoria == "FIN" else self.lexema.texto
        esperados = ", ".join(f'"{v}"' for v in self.validos)
        return f'<{self.lexema.fila},{self.lexema.col}> Error sintáctico: encontrado "{tok_mostrar}"; esperado: {esperados}'


class FalloSemantica(ExcepcionAnalisis):
    """Error durante análisis semántico"""
    def __init__(self, msg: str, lex=None):
        self.mensaje = msg
        self.lexema = lex
    
    def __str__(self):
        if self.lexema:
            return f'<{self.lexema.fila},{self.lexema.col}> Error semántico: {self.mensaje}'
        return f'Error semántico: {self.mensaje}'


# ============================================================================
# REPRESENTACIÓN DEL ÁRBOL SINTÁCTICO
# ============================================================================

class Nodo:
    """Nodo en el árbol de sintaxis abstracta"""
    def __init__(self, clase: str, dato=None):
        self.clase = clase
        self.dato = dato
        self.descendientes: List['Nodo'] = []
        self.propiedades = {}
    
    def anexar(self, hijo: 'Nodo'):
        self.descendientes.append(hijo)
    
    def definir(self, clave: str, valor):
        self.propiedades[clave] = valor
    
    def consultar(self, clave: str):
        return self.propiedades.get(clave)


# ============================================================================
# ADMINISTRADOR DE SÍMBOLOS
# ============================================================================

@dataclass
class InfoSimbolo:
    """Información de un símbolo en la tabla"""
    identificador: str
    tipoDato: str
    valorAsignado: Any = None
    lineaDeclaracion: int = 0


class ContextoEjecucion:
    """Representa un contexto de ejecución (scope) con símbolos"""
    def __init__(self, contexto_padre=None, etiqueta="raiz"):
        self.padre = contexto_padre
        self.etiqueta = etiqueta
        self.registro: Dict[str, InfoSimbolo] = {}
    
    def registrar(self, id: str, tipo: str, valor=None, linea: int = 0) -> bool:
        if id in self.registro:
            return False
        self.registro[id] = InfoSimbolo(id, tipo, valor, linea)
        return True
    
    def buscarLocal(self, id: str) -> Optional[InfoSimbolo]:
        return self.registro.get(id)
    
    def resolver(self, id: str) -> Optional[InfoSimbolo]:
        """Busca el símbolo en este contexto y los padres"""
        ctx = self
        while ctx:
            info = ctx.buscarLocal(id)
            if info:
                return info
            ctx = ctx.padre
        return None


# ============================================================================
# TOKENIZADOR (ANÁLISIS LÉXICO)
# ============================================================================

OPERADORES = {
    "(": "PAREN_ABRE", ")": "PAREN_CIERRA",
    "{": "CORCHETE_ABRE", "}": "CORCHETE_CIERRA",
    "+": "SUMA", "-": "RESTA",
    "*": "MULTIPLICACION", "/": "DIVISION",
    "=": "IGUAL", ";": "FINLINEA",
    ",": "SEPARADOR",
    "==": "COMPARAIGUAL", "!=": "COMPARADIF",
    "<": "COMPARAMENOR", ">": "COMPARAMAYOR",
    "<=": "MENORIGUAL", ">=": "MAYORIGUAL",
}

RESERVADAS = {
    "int": "TIPO_ENTERO",
    "float": "TIPO_REAL",
    "if": "CONDICIONAL",
    "while": "BUCLE",
    "else": "ALTERNATIVA",
    "print": "SALIDA",
}


class Tokenizador:
    """Convierte código fuente en tokens"""
    def __init__(self, fuente: str):
        self.fuente = fuente
        self.indice = 0
        self.fila = 1
        self.col = 1
        self.tokens: List[Lexema] = []
        self._procesar()
    
    def _avanzar(self):
        if self.indice < len(self.fuente):
            c = self.fuente[self.indice]
            self.indice += 1
            if c == '\n':
                self.fila += 1
                self.col = 1
            else:
                self.col += 1
            return c
        return None
    
    def _ver(self, offset=0):
        pos = self.indice + offset
        if pos < len(self.fuente):
            return self.fuente[pos]
        return None
    
    def _leer_cadena(self, largo=1):
        fin = self.indice + largo
        if fin <= len(self.fuente):
            return self.fuente[self.indice:fin]
        return None
    
    def _procesar(self):
        while self.indice < len(self.fuente):
            c = self._ver()
            
            # Espacios
            if c in " \t\n\r":
                self._avanzar()
                continue
            
            # Comentarios
            if c == '/' and self._leer_cadena(2) == "//":
                while c and c != '\n':
                    c = self._avanzar()
                continue
            
            # Operadores de dos caracteres
            if c in "!=<>":
                doble = self._leer_cadena(2)
                if doble in ["==", "!=", "<=", ">="]:
                    col_inicio = self.col
                    self._avanzar()
                    self._avanzar()
                    self.tokens.append(Lexema(OPERADORES[doble], doble, self.fila, col_inicio))
                    continue
            
            # Operadores simples
            if c in OPERADORES:
                col_inicio = self.col
                self._avanzar()
                self.tokens.append(Lexema(OPERADORES[c], c, self.fila, col_inicio))
                continue
            
            # Números
            if c.isdigit():
                col_inicio = self.col
                numero = ""
                punto = False
                while c and (c.isdigit() or (c == '.' and not punto)):
                    if c == '.':
                        punto = True
                    numero += self._avanzar()
                    c = self._ver()
                valor = float(numero) if punto else int(numero)
                self.tokens.append(Lexema("LITERAL_NUM", numero, self.fila, col_inicio, valor))
                continue
            
            # Identificadores y palabras reservadas
            if c.isalpha() or c == '_':
                col_inicio = self.col
                palabra = ""
                while c and (c.isalnum() or c == '_'):
                    palabra += self._avanzar()
                    c = self._ver()
                
                if palabra in RESERVADAS:
                    self.tokens.append(Lexema(RESERVADAS[palabra], palabra, self.fila, col_inicio))
                else:
                    self.tokens.append(Lexema("NOMBRE", palabra, self.fila, col_inicio))
                continue
            
            # Carácter desconocido
            col_inicio = self.col
            self._avanzar()
            self.tokens.append(Lexema("INVALIDO", c, self.fila, col_inicio))
        
        self.tokens.append(Lexema("FIN", "$", self.fila, self.col))


# ============================================================================
# ANALIZADOR SINTÁCTICO DESCENDENTE RECURSIVO
# ============================================================================

class AnalizadorSintactico:
    """Parser LL(1) con análisis semántico integrado"""
    def __init__(self, lista_tokens: List[Lexema]):
        self.tokens = lista_tokens
        self.cursor = 0
        self.token_actual: Lexema = None
        self.contexto = ContextoEjecucion()
        self._siguiente()
    
    def _siguiente(self):
        if self.cursor < len(self.tokens):
            self.token_actual = self.tokens[self.cursor]
            self.cursor += 1
    
    def _consumir(self, categoria: str) -> Lexema:
        if self.token_actual.categoria == categoria:
            tok = self.token_actual
            self._siguiente()
            return tok
        else:
            raise FalloSintaxis(self.token_actual, [categoria])
    
    def _nuevo_contexto(self, nombre="local"):
        nuevo = ContextoEjecucion(self.contexto, nombre)
        self.contexto = nuevo
        return nuevo
    
    def _salir_contexto(self):
        if self.contexto.padre:
            self.contexto = self.contexto.padre
    
    def parsear(self) -> Nodo:
        """Programa → {Declaracion} {Sentencia}"""
        raiz = Nodo("RAIZ")
        
        while self.token_actual.categoria in ["TIPO_ENTERO", "TIPO_REAL"]:
            decl = self._parsear_declaracion()
            raiz.anexar(decl)
        
        while self.token_actual.categoria != "FIN":
            sent = self._parsear_sentencia()
            raiz.anexar(sent)
        
        self._consumir("FIN")
        return raiz
    
    def _parsear_declaracion(self) -> Nodo:
        """Declaracion → Tipo id ;"""
        tipo_dato = self._parsear_tipo()
        nombre_tok = self._consumir("NOMBRE")
        self._consumir("FINLINEA")
        
        # Análisis semántico: registrar variable
        if not self.contexto.registrar(nombre_tok.texto, tipo_dato, linea=nombre_tok.fila):
            raise FalloSemantica(f"Variable '{nombre_tok.texto}' redeclarada", nombre_tok)
        
        nodo = Nodo("DECL")
        nodo.anexar(Nodo("TIPO", tipo_dato))
        nodo.anexar(Nodo("VAR", nombre_tok.texto))
        nodo.definir("tipo", tipo_dato)
        nodo.definir("variable", nombre_tok.texto)
        return nodo
    
    def _parsear_tipo(self) -> str:
        """Tipo → int | float"""
        if self.token_actual.categoria == "TIPO_ENTERO":
            self._consumir("TIPO_ENTERO")
            return "int"
        elif self.token_actual.categoria == "TIPO_REAL":
            self._consumir("TIPO_REAL")
            return "float"
        else:
            raise FalloSintaxis(self.token_actual, ["TIPO_ENTERO", "TIPO_REAL"])
    
    def _parsear_sentencia(self) -> Nodo:
        """Sentencia → Asignacion | Condicional | Bucle | Bloque | Imprimir"""
        if self.token_actual.categoria == "NOMBRE":
            return self._parsear_asignacion()
        elif self.token_actual.categoria == "CONDICIONAL":
            return self._parsear_condicional()
        elif self.token_actual.categoria == "BUCLE":
            return self._parsear_bucle()
        elif self.token_actual.categoria == "CORCHETE_ABRE":
            return self._parsear_bloque()
        elif self.token_actual.categoria == "SALIDA":
            return self._parsear_imprimir()
        else:
            raise FalloSintaxis(self.token_actual, 
                ["NOMBRE", "CONDICIONAL", "BUCLE", "CORCHETE_ABRE", "SALIDA"])
    
    def _parsear_asignacion(self) -> Nodo:
        """Asignacion → id = Expresion ;"""
        var_tok = self._consumir("NOMBRE")
        
        # Verificar que existe
        info = self.contexto.resolver(var_tok.texto)
        if not info:
            raise FalloSemantica(f"Variable '{var_tok.texto}' no declarada", var_tok)
        
        self._consumir("IGUAL")
        expr = self._parsear_expresion()
        self._consumir("FINLINEA")
        
        nodo = Nodo("ASIG")
        nodo.anexar(Nodo("VAR", var_tok.texto))
        nodo.anexar(expr)
        nodo.definir("variable", var_tok.texto)
        nodo.definir("tipoVar", info.tipoDato)
        return nodo
    
    def _parsear_condicional(self) -> Nodo:
        """Condicional → if ( Expresion ) Sentencia [else Sentencia]"""
        self._consumir("CONDICIONAL")
        self._consumir("PAREN_ABRE")
        condicion = self._parsear_expresion()
        self._consumir("PAREN_CIERRA")
        
        rama_si = self._parsear_sentencia()
        
        nodo = Nodo("SI")
        nodo.anexar(condicion)
        nodo.anexar(rama_si)
        
        if self.token_actual.categoria == "ALTERNATIVA":
            self._consumir("ALTERNATIVA")
            rama_no = self._parsear_sentencia()
            nodo.anexar(rama_no)
        
        return nodo
    
    def _parsear_bucle(self) -> Nodo:
        """Bucle → while ( Expresion ) Sentencia"""
        self._consumir("BUCLE")
        self._consumir("PAREN_ABRE")
        condicion = self._parsear_expresion()
        self._consumir("PAREN_CIERRA")
        
        cuerpo = self._parsear_sentencia()
        
        nodo = Nodo("CICLO")
        nodo.anexar(condicion)
        nodo.anexar(cuerpo)
        return nodo
    
    def _parsear_bloque(self) -> Nodo:
        """Bloque → { {Sentencia} }"""
        self._consumir("CORCHETE_ABRE")
        
        self._nuevo_contexto("bloque")
        
        nodo = Nodo("BLOQUE")
        while self.token_actual.categoria != "CORCHETE_CIERRA" and self.token_actual.categoria != "FIN":
            sent = self._parsear_sentencia()
            nodo.anexar(sent)
        
        self._consumir("CORCHETE_CIERRA")
        self._salir_contexto()
        
        return nodo
    
    def _parsear_imprimir(self) -> Nodo:
        """Imprimir → print Expresion ;"""
        self._consumir("SALIDA")
        expr = self._parsear_expresion()
        self._consumir("FINLINEA")
        
        nodo = Nodo("MOSTRAR")
        nodo.anexar(expr)
        return nodo
    
    def _parsear_expresion(self) -> Nodo:
        """Expresion → Termino ExprPrima"""
        term = self._parsear_termino()
        return self._parsear_expresion_prima(term)
    
    def _parsear_expresion_prima(self, izq: Nodo) -> Nodo:
        if self.token_actual.categoria in ["SUMA", "RESTA", "COMPARAIGUAL", 
                "COMPARADIF", "COMPARAMENOR", "COMPARAMAYOR", "MENORIGUAL", "MAYORIGUAL"]:
            op = self.token_actual.texto
            self._siguiente()
            der = self._parsear_termino()
            
            nodo_op = Nodo("OP", op)
            nodo_op.anexar(izq)
            nodo_op.anexar(der)
            
            # Calcular tipo resultante
            tipo_izq = izq.consultar("tipo") or "int"
            tipo_der = der.consultar("tipo") or "int"
            
            if op in ["==", "!=", "<", ">", "<=", ">="]:
                nodo_op.definir("tipo", "bool")
            elif tipo_izq == "float" or tipo_der == "float":
                nodo_op.definir("tipo", "float")
            else:
                nodo_op.definir("tipo", "int")
            
            return self._parsear_expresion_prima(nodo_op)
        else:
            return izq
    
    def _parsear_termino(self) -> Nodo:
        """Termino → Factor TerminoPrima"""
        fact = self._parsear_factor()
        return self._parsear_termino_prima(fact)
    
    def _parsear_termino_prima(self, izq: Nodo) -> Nodo:
        if self.token_actual.categoria in ["MULTIPLICACION", "DIVISION"]:
            op = self.token_actual.texto
            self._siguiente()
            der = self._parsear_factor()
            
            nodo_op = Nodo("OP", op)
            nodo_op.anexar(izq)
            nodo_op.anexar(der)
            
            tipo_izq = izq.consultar("tipo") or "int"
            tipo_der = der.consultar("tipo") or "int"
            
            if tipo_izq == "float" or tipo_der == "float":
                nodo_op.definir("tipo", "float")
            else:
                nodo_op.definir("tipo", "int")
            
            return self._parsear_termino_prima(nodo_op)
        else:
            return izq
    
    def _parsear_factor(self) -> Nodo:
        """Factor → ( Expresion ) | id | numero"""
        if self.token_actual.categoria == "PAREN_ABRE":
            self._consumir("PAREN_ABRE")
            expr = self._parsear_expresion()
            self._consumir("PAREN_CIERRA")
            return expr
        elif self.token_actual.categoria == "LITERAL_NUM":
            tok = self._consumir("LITERAL_NUM")
            nodo = Nodo("NUMERO", tok.dato)
            tipo = "float" if isinstance(tok.dato, float) else "int"
            nodo.definir("tipo", tipo)
            return nodo
        elif self.token_actual.categoria == "NOMBRE":
            tok = self._consumir("NOMBRE")
            
            info = self.contexto.resolver(tok.texto)
            if not info:
                raise FalloSemantica(f"Variable '{tok.texto}' no declarada", tok)
            
            nodo = Nodo("VAR", tok.texto)
            nodo.definir("tipo", info.tipoDato)
            return nodo
        else:
            raise FalloSintaxis(self.token_actual, ["PAREN_ABRE", "LITERAL_NUM", "NOMBRE"])


# ============================================================================
# GENERADOR DE CÓDIGO INTERMEDIO
# ============================================================================

class ConstructorCodigoIntermedio:
    """Genera código de tres direcciones desde el AST"""
    def __init__(self):
        self.instrucciones: List[str] = []
        self.variables_temp: List[tuple] = []
        self.cont_temp = 0
        self.cont_etiqueta = 0
        self.vars_declaradas = set()
    
    def _generar_temporal(self, tipo="float") -> str:
        nombre = f"temp{self.cont_temp}"
        self.cont_temp += 1
        self.variables_temp.append((nombre, tipo))
        return nombre
    
    def _generar_etiqueta(self) -> str:
        etiq = f"Etiq{self.cont_etiqueta}"
        self.cont_etiqueta += 1
        return etiq
    
    def construir(self, nodo: Nodo) -> str:
        """Procesa un nodo del AST y genera código"""
        if nodo.clase == "RAIZ":
            for hijo in nodo.descendientes:
                self.construir(hijo)
            return ""
        
        elif nodo.clase == "DECL":
            var = nodo.consultar("variable")
            tipo = nodo.consultar("tipo")
            if var not in self.vars_declaradas:
                self.instrucciones.append(f"DECLARE {var} {tipo}")
                self.vars_declaradas.add(var)
            return ""
        
        elif nodo.clase == "ASIG":
            var = nodo.consultar("variable")
            temp_expr = self.construir(nodo.descendientes[1])
            self.instrucciones.append(f"{var} = {temp_expr}")
            return var
        
        elif nodo.clase == "OP":
            temp_izq = self.construir(nodo.descendientes[0])
            temp_der = self.construir(nodo.descendientes[1])
            operador = nodo.dato
            
            mapeo = {
                '+': 'ADD', '-': 'SUB', '*': 'MUL', '/': 'DIV',
                '==': 'EQ', '!=': 'NE', '<': 'LT', '>': 'GT',
                '<=': 'LE', '>=': 'GE'
            }
            
            temporal = self._generar_temporal(nodo.consultar("tipo") or "float")
            
            if operador in mapeo:
                instruccion = f"{temporal} = {mapeo[operador]} {temp_izq} {temp_der}"
            else:
                instruccion = f"{temporal} = {temp_izq} {operador} {temp_der}"
            
            self.instrucciones.append(instruccion)
            return temporal
        
        elif nodo.clase == "NUMERO":
            return str(nodo.dato)
        
        elif nodo.clase == "VAR":
            return nodo.dato
        
        elif nodo.clase == "SI":
            temp_cond = self.construir(nodo.descendientes[0])
            etiq_sino = self._generar_etiqueta()
            etiq_fin = self._generar_etiqueta()
            
            self.instrucciones.append(f"IFFALSE {temp_cond} GOTO {etiq_sino}")
            
            self.construir(nodo.descendientes[1])
            self.instrucciones.append(f"GOTO {etiq_fin}")
            
            self.instrucciones.append(f"{etiq_sino}:")
            if len(nodo.descendientes) > 2:
                self.construir(nodo.descendientes[2])
            
            self.instrucciones.append(f"{etiq_fin}:")
            return ""
        
        elif nodo.clase == "CICLO":
            etiq_inicio = self._generar_etiqueta()
            etiq_salida = self._generar_etiqueta()
            
            self.instrucciones.append(f"{etiq_inicio}:")
            temp_cond = self.construir(nodo.descendientes[0])
            self.instrucciones.append(f"IFFALSE {temp_cond} GOTO {etiq_salida}")
            
            self.construir(nodo.descendientes[1])
            self.instrucciones.append(f"GOTO {etiq_inicio}")
            self.instrucciones.append(f"{etiq_salida}:")
            return ""
        
        elif nodo.clase == "BLOQUE":
            for hijo in nodo.descendientes:
                self.construir(hijo)
            return ""
        
        elif nodo.clase == "MOSTRAR":
            temp_expr = self.construir(nodo.descendientes[0])
            self.instrucciones.append(f"PRINT {temp_expr}")
            return ""
        
        return ""
    
    def obtener_resultado(self) -> List[str]:
        return self.instrucciones
    
    def reiniciar(self):
        self.instrucciones.clear()
        self.variables_temp.clear()
        self.cont_temp = 0
        self.cont_etiqueta = 0
        self.vars_declaradas.clear()


# ============================================================================
# VISUALIZADOR DE ÁRBOL
# ============================================================================

class ImpresarArbol:
    @staticmethod
    def mostrar(nodo: Nodo, nivel: int = 0) -> List[str]:
        lineas = []
        indent = "  " * nivel
        
        if nodo.clase == "OP":
            nombres_ops = {
                '+': 'SUMA', '-': 'RESTA', '*': 'MULTIPLICACION',
                '/': 'DIVISION', '==': 'IGUAL', '!=': 'DIFERENTE',
                '<': 'MENOR', '>': 'MAYOR', '<=': 'MENOR_IGUAL', '>=': 'MAYOR_IGUAL'
            }
            info = f"Operación: {nombres_ops.get(nodo.dato, nodo.dato)}"
            tipo = nodo.consultar("tipo")
            if tipo:
                info += f" [{tipo}]"
            lineas.append(indent + info)
            
        elif nodo.clase == "NUMERO":
            info = f"Número: {nodo.dato}"
            tipo = nodo.consultar("tipo")
            if tipo:
                info += f" [{tipo}]"
            lineas.append(indent + info)
            
        elif nodo.clase == "VAR":
            info = f"Variable: {nodo.dato}"
            tipo = nodo.consultar("tipo")
            if tipo:
                info += f" [{tipo}]"
            lineas.append(indent + info)
            
        elif nodo.clase == "DECL":
            tipo_var = nodo.consultar("tipo")
            nombre_var = nodo.consultar("variable")
            lineas.append(indent + f"DECLARACION: {nombre_var} [{tipo_var}]")
            
        elif nodo.clase == "ASIG":
            nombre_var = nodo.consultar("variable")
            lineas.append(indent + f"Asignación: {nombre_var}")
            
        elif nodo.clase == "SI":
            lineas.append(indent + "IF")
            
        elif nodo.clase == "CICLO":
            lineas.append(indent + "WHILE")
            
        elif nodo.clase == "BLOQUE":
            lineas.append(indent + "BLOQUE")
            
        elif nodo.clase == "MOSTRAR":
            lineas.append(indent + "PRINT")
            
        elif nodo.clase == "RAIZ":
            lineas.append(indent + "PROGRAMA")
            
        else:
            lineas.append(indent + nodo.clase)
        
        for hijo in nodo.descendientes:
            lineas.extend(ImpresarArbol.mostrar(hijo, nivel + 1))
        
        return lineas


# ============================================================================
# FUNCIÓN PRINCIPAL DE COMPILACIÓN
# ============================================================================

def compilar_codigo(codigo_fuente: str) -> str:
    """Compila el código y genera reporte completo"""
    salida = []
    t_inicio = time.time()

    salida.append("Codigo 3 Direcciones ")
    salida.append(f"PROGRAMA:")
    salida.append(f"{codigo_fuente}")
    salida.append("")
    
    try:
        # FASE 1: Tokenización
        tokenizador = Tokenizador(codigo_fuente)
        tokens_invalidos = [t for t in tokenizador.tokens if t.categoria == "INVALIDO"]
        
        if tokens_invalidos:
            salida.append("ERROR LÉXICO")
            salida.append("")
            for tok_err in tokens_invalidos:
                salida.append(f"   Carácter inválido '{tok_err.texto}' en línea {tok_err.fila}, columna {tok_err.col}")
            return '\n'.join(salida)
        
        # FASE 2: Análisis sintáctico y semántico
        analizador = AnalizadorSintactico(tokenizador.tokens)
        arbol = analizador.parsear()
        
        # FASE 3: Generación de código intermedio
        generador = ConstructorCodigoIntermedio()
        generador.construir(arbol)
        
        # REPORTE EXITOSO
        salida.append("ANALISIS EXITOSO")
        salida.append("")
        
        # Tabla de símbolos
        salida.append("TABLA DE SÍMBOLOS (Ámbito global):")
        salida.append("-" * 40)
        if analizador.contexto.registro:
            for nombre, info in analizador.contexto.registro.items():
                salida.append(f"   {nombre:<5} : {info.tipoDato:<5} (línea {info.lineaDeclaracion})")
        else:
            salida.append("   (sin variables declaradas)")
        salida.append("")
        
        # Código intermedio
        salida.append("CÓDIGO DE TRES DIRECCIONES GENERADO:")
        salida.append("-" * 40)
        if generador.obtener_resultado():
            for idx, instr in enumerate(generador.obtener_resultado(), 1):
                salida.append(f"   {idx:3d}. {instr}")
        else:
            salida.append("   (sin código generado)")
        salida.append("")
        
        # Temporales utilizados
        if generador.variables_temp:
            salida.append("VARIABLES TEMPORALES:")
            salida.append("-" * 40)
            for temp, tipo in generador.variables_temp:
                salida.append(f"   {temp:<5} : {tipo}")
            salida.append("")
        
        # Árbol AST
        salida.append("ARBOL DE SINTAXIS ABSTRACTA (AST):")
        salida.append("-" * 40)
        lineas_arbol = ImpresarArbol.mostrar(arbol)
        for linea in lineas_arbol:
            salida.append("   " + linea)
        salida.append("")
        
    except FalloSintaxis as error:
        salida.append("ERROR SINTACTICO")
        salida.append("")
        salida.append(f"   {error}")
        return '\n'.join(salida)
    except FalloSemantica as error:
        salida.append("ERROR SEMANTICO")
        salida.append("")
        salida.append(f"   {error}")
        return '\n'.join(salida)
    except Exception as error:
        salida.append("ERROR INESPERADO")
        salida.append("")
        salida.append(f"   {error}")
        import traceback
        salida.append(f"   {traceback.format_exc()}")
        return '\n'.join(salida)
    
    t_fin = time.time()
    tiempo_total = t_fin - t_inicio
    salida.append("-" * 70)
    salida.append(f"Tiempo de ejecución: {tiempo_total:.4f} segundos")
    salida.append("")
    
    return '\n'.join(salida)


def main():
    # Si no hay argumentos, usar un archivo por defecto para pruebas
    if len(sys.argv) == 1:
        print("⚠️  No se especificó archivo. Usando 'programa.txt' por defecto...")
        archivo = "programa.txt"
    elif len(sys.argv) != 2:
        print("Codigo 3 direcciones")
        print("")
        print("Uso:")
        print("  python compilador.py <archivo.txt>")
        print("")
        print("Ejemplo:")
        print("  python compilador.py programa.txt")
        print("")
        sys.exit(1)
    else:
        archivo = sys.argv[1]

    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            contenido = f.read().strip()

        if not contenido:
            print(f"[Error] El archivo '{archivo}' está vacío")
            sys.exit(1)

        print(f"\n[Analizando: {archivo}]\n")

        resultado = compilar_codigo(contenido)
        print(resultado)

        # Guardar resultado
        nombre_salida = archivo.replace('.txt', '_output.txt')
        with open(nombre_salida, "w", encoding="utf-8") as f:
            f.write(resultado)

        print(f"\n[Resultados guardados en: {nombre_salida}]")

    except FileNotFoundError:
        print(f"[Error] No se encontró el archivo '{archivo}'")
        sys.exit(1)
    except Exception as error:
        print(f"[Error inesperado] {error}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()