import java.util.HashMap;
import java.util.Map;

public class EvalVisitor extends LabeledExprBaseVisitor<Integer> {
    Map<String, Integer> memory = new HashMap<>();

    @Override
    public Integer visitAssign(LabeledExprParser.AssignContext ctx) {
        String id = ctx.ID().getText();
        int value = visit(ctx.expr());
        memory.put(id, value);
        return value;
    }

    @Override
    public Integer visitPrintExpr(LabeledExprParser.PrintExprContext ctx) {
        Integer value = visit(ctx.expr());
        System.out.println(value);
        return 0;
    }

    @Override
    public Integer visitInt(LabeledExprParser.IntContext ctx) {
        return Integer.valueOf(ctx.INT().getText());
    }

    @Override
    public Integer visitId(LabeledExprParser.IdContext ctx) {
        String id = ctx.ID().getText();
        return memory.getOrDefault(id, 0);
    }

    @Override
    public Integer visitMulDiv(LabeledExprParser.MulDivContext ctx) {
        int left = visit(ctx.expr(0));
        int right = visit(ctx.expr(1));
        if (ctx.op.getType() == LabeledExprParser.MUL) return left * right;
        return left / right;
    }

    @Override
    public Integer visitAddSub(LabeledExprParser.AddSubContext ctx) {
        int left = visit(ctx.expr(0));
        int right = visit(ctx.expr(1));
        if (ctx.op.getType() == LabeledExprParser.ADD) return left + right;
        return left - right;
    }

    @Override
    public Integer visitParens(LabeledExprParser.ParensContext ctx) {
        return visit(ctx.expr());
    }

    @Override
    public Integer visitPower(LabeledExprParser.PowerContext ctx) {
        int base = visit(ctx.expr(0));
        int exp = visit(ctx.expr(1));
        return (int) Math.round(Math.pow(base, exp));
    }

    @Override
    public Integer visitFactorial(LabeledExprParser.FactorialContext ctx) {
        int value = visit(ctx.expr());
        return factorial(value);
    }

    private int factorial(int n) {
        if (n < 0) throw new RuntimeException("Factorial indefinido para negativos");
        int result = 1;
        for (int i = 2; i <= n; i++) result *= i;
        return result;
    }

    // ---- FUNCIONES MATEMÁTICAS ----

    @Override
    public Integer visitSinFunc(LabeledExprParser.SinFuncContext ctx) {
        int value = visit(ctx.expr());
        return (int) Math.round(Math.sin(Math.toRadians(value)));
    }

    @Override
    public Integer visitCosFunc(LabeledExprParser.CosFuncContext ctx) {
        int value = visit(ctx.expr());
        return (int) Math.round(Math.cos(Math.toRadians(value)));
    }

    @Override
    public Integer visitTanFunc(LabeledExprParser.TanFuncContext ctx) {
        int value = visit(ctx.expr());
        return (int) Math.round(Math.tan(Math.toRadians(value)));
    }

    @Override
    public Integer visitSqrtFunc(LabeledExprParser.SqrtFuncContext ctx) {
        int value = visit(ctx.expr());
        return (int) Math.round(Math.sqrt(value));
    }

    @Override
    public Integer visitLnFunc(LabeledExprParser.LnFuncContext ctx) {
        int value = visit(ctx.expr());
        return (int) Math.round(Math.log(value)); // ln = log base e
    }

    @Override
    public Integer visitLogFunc(LabeledExprParser.LogFuncContext ctx) {
        int value = visit(ctx.expr());
        return (int) Math.round(Math.log10(value)); // log base 10
    }
}
