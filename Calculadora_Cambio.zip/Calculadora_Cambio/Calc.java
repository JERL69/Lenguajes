import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class Calc {
    public static void main(String[] args) throws Exception {
        // Lee el archivo de entrada
        CharStream input = CharStreams.fromFileName("t.expr");

        // Pasa el input al lexer
        LabeledExprLexer lexer = new LabeledExprLexer(input);

        // Convierte los tokens
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        // Pasa los tokens al parser
        LabeledExprParser parser = new LabeledExprParser(tokens);

        // Inicia en la regla "prog"
        ParseTree tree = parser.prog(); // parse

        // Crea el visitor
        EvalVisitor eval = new EvalVisitor();

        // Visita el árbol
        eval.visit(tree);
    }
}
