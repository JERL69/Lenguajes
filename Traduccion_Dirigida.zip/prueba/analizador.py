"""
EDTS (Esquema de Traducción Dirigido por la Sintaxis)
Para una GIC que suma, resta, multiplica y divide
"""

class Token:
    def __init__(self, tipo, valor):
        self.tipo = tipo
        self.valor = valor
    
    def __repr__(self):
        return f"Token({self.tipo}, {self.valor})"


class Lexer:
    """Analizador léxico"""
    def __init__(self, texto):
        self.texto = texto.replace(" ", "")  # Eliminar espacios
        self.pos = 0
        self.char_actual = self.texto[0] if self.texto else None
    
    def avanzar(self):
        self.pos += 1
        if self.pos < len(self.texto):
            self.char_actual = self.texto[self.pos]
        else:
            self.char_actual = None
    
    def obtener_numero(self):
        resultado = ""
        while self.char_actual is not None and (self.char_actual.isdigit() or self.char_actual == '.'):
            resultado += self.char_actual
            self.avanzar()
        return float(resultado) if '.' in resultado else int(resultado)
    
    def obtener_tokens(self):
        tokens = []
        while self.char_actual is not None:
            if self.char_actual.isdigit():
                tokens.append(Token('NUM', self.obtener_numero()))
            elif self.char_actual == '+':
                tokens.append(Token('MAS', '+'))
                self.avanzar()
            elif self.char_actual == '-':
                tokens.append(Token('MENOS', '-'))
                self.avanzar()
            elif self.char_actual == '*':
                tokens.append(Token('MUL', '*'))
                self.avanzar()
            elif self.char_actual == '/':
                tokens.append(Token('DIV', '/'))
                self.avanzar()
            elif self.char_actual == '(':
                tokens.append(Token('PAREN_IZQ', '('))
                self.avanzar()
            elif self.char_actual == ')':
                tokens.append(Token('PAREN_DER', ')'))
                self.avanzar()
            else:
                raise Exception(f"Carácter inválido: {self.char_actual}")
        
        tokens.append(Token('EOF', None))
        return tokens


class Nodo:
    """Nodo del AST"""
    pass


class NodoNumero(Nodo):
    def __init__(self, valor):
        self.valor = valor
    
    def __repr__(self):
        return f"Num({self.valor})"


class NodoBinario(Nodo):
    def __init__(self, izquierdo, operador, derecho):
        self.izquierdo = izquierdo
        self.operador = operador
        self.derecho = derecho
    
    def __repr__(self):
        return f"BinOp({self.izquierdo} {self.operador} {self.derecho})"


class Parser:
    """
    Gramática:
    E -> T E'
    E' -> + T E' | - T E' | ε
    T -> F T'
    T' -> * F T' | / F T' | ε
    F -> NUM | ( E )
    """
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.token_actual = self.tokens[0]
    
    def avanzar(self):
        self.pos += 1
        if self.pos < len(self.tokens):
            self.token_actual = self.tokens[self.pos]
    
    def parsear(self):
        return self.expresion()
    
    def expresion(self):
        # E -> T E'
        nodo = self.termino()
        return self.expresion_prima(nodo)
    
    def expresion_prima(self, izquierdo):
        # E' -> + T E' | - T E' | ε
        if self.token_actual.tipo in ('MAS', 'MENOS'):
            operador = self.token_actual.valor
            self.avanzar()
            derecho = self.termino()
            nodo = NodoBinario(izquierdo, operador, derecho)
            return self.expresion_prima(nodo)
        return izquierdo
    
    def termino(self):
        # T -> F T'
        nodo = self.factor()
        return self.termino_primo(nodo)
    
    def termino_primo(self, izquierdo):
        # T' -> * F T' | / F T' | ε
        if self.token_actual.tipo in ('MUL', 'DIV'):
            operador = self.token_actual.valor
            self.avanzar()
            derecho = self.factor()
            nodo = NodoBinario(izquierdo, operador, derecho)
            return self.termino_primo(nodo)
        return izquierdo
    
    def factor(self):
        # F -> NUM | ( E )
        token = self.token_actual
        
        if token.tipo == 'NUM':
            self.avanzar()
            return NodoNumero(token.valor)
        elif token.tipo == 'PAREN_IZQ':
            self.avanzar()
            nodo = self.expresion()
            if self.token_actual.tipo != 'PAREN_DER':
                raise Exception("Se esperaba ')'")
            self.avanzar()
            return nodo
        else:
            raise Exception(f"Token inesperado: {token}")


class Evaluador:
    """Evaluador del AST - EDTS"""
    def __init__(self):
        self.pasos = []
    
    def evaluar(self, nodo):
        if isinstance(nodo, NodoNumero):
            return nodo.valor
        
        elif isinstance(nodo, NodoBinario):
            izq = self.evaluar(nodo.izquierdo)
            der = self.evaluar(nodo.derecho)
            
            if nodo.operador == '+':
                resultado = izq + der
                self.pasos.append(f"{izq} + {der} = {resultado}")
                return resultado
            elif nodo.operador == '-':
                resultado = izq - der
                self.pasos.append(f"{izq} - {der} = {resultado}")
                return resultado
            elif nodo.operador == '*':
                resultado = izq * der
                self.pasos.append(f"{izq} * {der} = {resultado}")
                return resultado
            elif nodo.operador == '/':
                if der == 0:
                    raise Exception("División por cero")
                resultado = izq / der
                self.pasos.append(f"{izq} / {der} = {resultado}")
                return resultado


def imprimir_ast(nodo, prefijo="", es_ultimo=True):
    """Imprime el AST de forma visual"""
    conectores = "└── " if es_ultimo else "├── "
    
    if isinstance(nodo, NodoNumero):
        print(f"{prefijo}{conectores}Número: {nodo.valor}")
    
    elif isinstance(nodo, NodoBinario):
        print(f"{prefijo}{conectores}Operador: {nodo.operador}")
        
        extension = "    " if es_ultimo else "│   "
        nuevo_prefijo = prefijo + extension
        
        imprimir_ast(nodo.izquierdo, nuevo_prefijo, False)
        imprimir_ast(nodo.derecho, nuevo_prefijo, True)


def calcular_conjuntos():
    """Calcula y muestra FIRST, FOLLOW y PREDICT"""
    print("\n" + "-"*60)
    print("3. CONJUNTOS FIRST, FOLLOW Y PREDICT")
    
    
    gramatica = """
Gramática:
    E  -> T E'
    E' -> + T E' | - T E' | ε
    T  -> F T'
    T' -> * F T' | / F T' | ε
    F  -> NUM | ( E )
    """
    print(gramatica)
    
    print("\nFIRST:")
    print("  FIRST(E)  = {NUM, (}")
    print("  FIRST(E') = {+, -, ε}")
    print("  FIRST(T)  = {NUM, (}")
    print("  FIRST(T') = {*, /, ε}")
    print("  FIRST(F)  = {NUM, (}")
    
    print("\nFOLLOW:")
    print("  FOLLOW(E)  = {$, )}")
    print("  FOLLOW(E') = {$, )}")
    print("  FOLLOW(T)  = {+, -, $, )}")
    print("  FOLLOW(T') = {+, -, $, )}")
    print("  FOLLOW(F)  = {*, /, +, -, $, )}")


def generar_tabla_simbolos():
    """Genera la tabla de símbolos (en este caso vacía porque solo hay números)"""
    print("\n" + "-"*60)
    print("5. TABLA DE SÍMBOLOS")
    
    print("No se utilizan variables en esta expresión.")
    print("Solo se trabaja con literales numéricos.")


def mostrar_gramatica_atributos():
    """Muestra la gramática de atributos"""
    print("\n" + "-"*60)
    print("6. GRAMÁTICA DE ATRIBUTOS")
    
    reglas = """
Reglas Semánticas:
    
    E  -> T E'          { E'.her = T.val; E.val = E'.sin }
    E' -> + T E'₁       { E'₁.her = E'.her + T.val; E'.sin = E'₁.sin }
    E' -> - T E'₁       { E'₁.her = E'.her - T.val; E'.sin = E'₁.sin }
    E' -> ε             { E'.sin = E'.her }
    
    T  -> F T'          { T'.her = F.val; T.val = T'.sin }
    T' -> * F T'₁       { T'₁.her = T'.her * F.val; T'.sin = T'₁.sin }
    T' -> / F T'₁       { T'₁.her = T'.her / F.val; T'.sin = T'₁.sin }
    T' -> ε             { T'.sin = T'.her }
    
    F  -> NUM           { F.val = NUM.lexval }
    F  -> ( E )         { F.val = E.val }

Donde:
    - .her = atributo heredado (fluye hacia abajo en el árbol)
    - .sin = atributo sintetizado (fluye hacia arriba en el árbol)
    - .val = valor calculado
    """
    print(reglas)


def main():
    # Leer archivo de entrada
    try:
        with open('entrada.txt', 'r', encoding='utf-8') as archivo:
            expresion = archivo.read().strip()
    except FileNotFoundError:
        print("Error: No se encontró el archivo 'entrada.txt'")
        print("Creando archivo de ejemplo...")
        with open('entrada.txt', 'w', encoding='utf-8') as archivo:
            archivo.write("3 + 5 * 2")
        expresion = "3 + 5 * 2"
    
    print("-"*60)
    print("ANALIZADOR ARITMÉTICO - EDTS")
    print("-"*60)
    print(f"\n1. ENTRADA: {expresion}")
    
    # Análisis léxico
    print("\n" + "-"*60)
    print("2. ANÁLISIS LÉXICO (TOKENS)")
    
    lexer = Lexer(expresion)
    tokens = lexer.obtener_tokens()
    for token in tokens:
        if token.tipo != 'EOF':
            print(f"  {token}")
    
    # Conjuntos
    calcular_conjuntos()
    
    # Análisis sintáctico
    print("\n" + "-"*60)
    print("4. AST DECORADO (ÁRBOL DE SINTAXIS ABSTRACTA)")
    
    parser = Parser(tokens)
    ast = parser.parsear()
    print("\nEstructura del árbol:")
    imprimir_ast(ast)
    
    # Tabla de símbolos
    generar_tabla_simbolos()
    
    # Gramática de atributos
    mostrar_gramatica_atributos()
    
    # EDTS - Evaluación
    print("\n" + "-"*60)
    print("7. EDTS - EVALUACIÓN Y TRADUCCIÓN")
    
    evaluador = Evaluador()
    resultado = evaluador.evaluar(ast)
    
    print("\nPasos de evaluación:")
    for i, paso in enumerate(evaluador.pasos, 1):
        print(f"  {i}. {paso}")
    
    print(f"RESULTADO FINAL: {resultado}")
    
    

if __name__ == "__main__":
    main()
