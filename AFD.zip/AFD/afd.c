#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_ESTADOS 50
#define MAX_SIMBOLOS 10
#define MAX_CADENA 100

// Es la estructura que guarda toda la info del autómata
typedef struct {
    char estados[MAX_ESTADOS][20];        // Lista de estados
    char alfabeto[MAX_SIMBOLOS];          // Símbolos permitidos
    char inicial[20];                     // Estado inicial
    char finales[MAX_ESTADOS][20];        // Estados finales
    char tabla[MAX_ESTADOS][MAX_SIMBOLOS][20]; // Tabla de transiciones, que es el que le dice al automata donde esta parado y hacia donde va a ir
    int cantEstados;
    int cantSimbolos;
    int cantFinales;
} Automata;

/*
 * Función: cargarConfig
 
 * Lee el archivo de configuración (Conf.txt) y carga:
 * - Estados
 * - Alfabeto
 * - Estado inicial
 * - Estados finales
 * - Transiciones
 */
void cargarConfig(const char* archivo, Automata* a) {
    FILE* file = fopen(archivo, "r");
    if (file == NULL) {
        printf("Error: No se pudo abrir %s\n", archivo);
        exit(1);
    }

    char linea[256];
    int seccion = 0;

    while (fgets(linea, sizeof(linea), file)) {
        linea[strcspn(linea, "\n")] = 0; // Quita salto de línea
        if (strlen(linea) == 0) continue;
        
        if (strstr(linea, "Estados:")) {
            seccion = 1;
            char* token = strtok(linea + 9, ",");
            a->cantEstados = 0;
            while (token != NULL) {
                strcpy(a->estados[a->cantEstados++], token);
                token = strtok(NULL, ",");
            }
        }
        else if (strstr(linea, "Alfabeto:")) {
            seccion = 2;
            char* token = strtok(linea + 10, ",");
            a->cantSimbolos = 0;
            while (token != NULL) {
                a->alfabeto[a->cantSimbolos++] = token[0];
                token = strtok(NULL, ",");
            }
        }
        else if (strstr(linea, "EstadoInicial:")) {
            strcpy(a->inicial, linea + 15);
        }
        else if (strstr(linea, "EstadosFinales:")) {
            seccion = 3;
            char* token = strtok(linea + 16, ",");
            a->cantFinales = 0;
            while (token != NULL) {
                strcpy(a->finales[a->cantFinales++], token);
                token = strtok(NULL, ",");
            }
        }
        else if (strstr(linea, "Transiciones:")) {
            seccion = 4;
        }
        else if (seccion == 4) {
            char origen[20], simbolo[2], destino[20];
            sscanf(linea, "%[^,],%[^,],%s", origen, simbolo, destino);
            
            int idxOrigen = -1, idxSimbolo = -1;
            
            for (int i = 0; i < a->cantEstados; i++) {
                if (strcmp(a->estados[i], origen) == 0) {
                    idxOrigen = i;
                    break;
                }
            }
            
            for (int i = 0; i < a->cantSimbolos; i++) {
                if (a->alfabeto[i] == simbolo[0]) {
                    idxSimbolo = i;
                    break;
                }
            }
            
            if (idxOrigen != -1 && idxSimbolo != -1) {
                strcpy(a->tabla[idxOrigen][idxSimbolo], destino);
            }
        }
    }
    
    fclose(file);
}

/*
 * Función: esFinal
 
 * Revisa si un estado dado está dentro de la lista de estados finales.
 * Retorna true si es final, false si no lo es.
 */
bool esFinal(Automata* a, const char* estado) {
    for (int i = 0; i < a->cantFinales; i++) {
        if (strcmp(a->finales[i], estado) == 0) {
            return true;
        }
    }
    return false;
}

/*
 * Función: posEstado
 
 * Busca el índice (posición) de un estado dentro de la lista de estados.
 * Si no lo encuentra, devuelve -1.
 */
int posEstado(Automata* a, const char* estado) {
    for (int i = 0; i < a->cantEstados; i++) {
        if (strcmp(a->estados[i], estado) == 0) {
            return i;
        }
    }
    return -1;
}

/*
 * Función: posSimbolo
 
 * Busca el índice (posición) de un símbolo dentro del alfabeto.
 * Si no lo encuentra, devuelve -1.
 */
int posSimbolo(Automata* a, char simbolo) {
    for (int i = 0; i < a->cantSimbolos; i++) {
        if (a->alfabeto[i] == simbolo) {
            return i;
        }
    }
    return -1;
}

/*
 * Función: probarCadena
 
 * Recorre el autómata con una cadena:
 * - Empieza desde el estado inicial
 * - Va moviéndose según los símbolos y la tabla de transiciones
 * - Al final, dice si la cadena fue ACEPTADA o RECHAZADA
 */
void probarCadena(Automata* a, const char* cadena) {
    char actual[20];
    strcpy(actual, a->inicial);
    
    printf("Cadena: %s\n", cadena);
    printf("Ruta: %s", actual);
    
    for (int i = 0; cadena[i] != '\0'; i++) {
        char simbolo = cadena[i];
        int idxE = posEstado(a, actual);
        int idxS = posSimbolo(a, simbolo);
        
        if (idxE == -1 || idxS == -1) {
            printf(" -> ERROR (símbolo no válido)\n");
            return;
        }
        
        strcpy(actual, a->tabla[idxE][idxS]);
        printf(" ->%c-> %s", simbolo, actual);
    }
    
    if (esFinal(a, actual)) {
        printf(" -> ACEPTADA\n");
    } else {
        printf(" -> RECHAZADA\n");
    }
}

/*
 * Función: probarArchivo
 
 * Abre el archivo de cadenas (Cadenas.txt) y las prueba una por una
 * usando la función probarCadena.
 */
void probarArchivo(Automata* a, const char* archivo) {
    FILE* file = fopen(archivo, "r");
    if (file == NULL) {
        printf("Error: No se pudo abrir %s\n", archivo);
        exit(1);
    }
    
    char cadena[MAX_CADENA];
    printf("\n=== RESULTADOS ===\n");
    
    while (fgets(cadena, sizeof(cadena), file)) {
        cadena[strcspn(cadena, "\n")] = 0;
        if (strlen(cadena) > 0) {
            probarCadena(a, cadena);
        }
    }
    
    fclose(file);
}

/*
 * Función principal (main)
 
 * - Carga el autómata desde Conf.txt
 * - Procesa todas las cadenas de Cadenas.txt
 */
int main() {
    Automata a;
    
    cargarConfig("Conf.txt", &a);
    probarArchivo(&a, "Cadenas.txt");
    
    return 0;
}

