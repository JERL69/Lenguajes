class AFD:
    def __init__(self):
        # Lista con los nombres de los estados (q0, q1, etc.)
        self.estados = []
        # Lista con el alfabeto (los símbolos permitidos: a, b, etc.)
        self.alfabeto = []
        # Estado inicial
        self.estado_inicial = ""
        # Lista con los estados finales
        self.estados_finales = []
        # Diccionario con las transiciones: {estado: {simbolo: estadoDestino}}
        self.transiciones = {}
    
    def cargar_configuracion(self, archivo_conf):
        """
        Lee la configuración del AFD desde un archivo.
        El archivo debe tener las secciones:
        - Estados
        - Alfabeto
        - EstadoInicial
        - EstadosFinales
        - Transiciones
        """
        try:
            with open(archivo_conf, 'r', encoding='utf-8') as f:
                lineas = f.readlines()
                
            seccion = None
            
            for linea in lineas:
                linea = linea.strip()
                if not linea:
                    continue
                    
                if linea.startswith("Estados:"):
                    seccion = "estados"
                    lista_estados = linea.split(":")[1].strip()
                    self.estados = [e.strip() for e in lista_estados.split(",")]
                    
                elif linea.startswith("Alfabeto:"):
                    seccion = "alfabeto"
                    lista_simbolos = linea.split(":")[1].strip()
                    self.alfabeto = [a.strip() for a in lista_simbolos.split(",")]
                    
                elif linea.startswith("EstadoInicial:"):
                    self.estado_inicial = linea.split(":")[1].strip()
                    
                elif linea.startswith("EstadosFinales:"):
                    seccion = "finales"
                    lista_finales = linea.split(":")[1].strip()
                    self.estados_finales = [f.strip() for f in lista_finales.split(",")]
                    
                elif linea.startswith("Transiciones:"):
                    seccion = "transiciones"
                    self.transiciones = {}
                    
                elif seccion == "transiciones":
                    partes = linea.split(",")
                    if len(partes) == 3:
                        origen, simbolo, destino = [p.strip() for p in partes]
                        
                        if origen not in self.transiciones:
                            self.transiciones[origen] = {}
                        self.transiciones[origen][simbolo] = destino
            
            # Aquì se valida que la configuración sea correcta
            return self.validar_configuracion()
                        
        except FileNotFoundError:
            print(f"Error: No se encontró el archivo {archivo_conf}")
            return False
        except Exception as e:
            print(f"Error al leer configuración: {e}")
            return False
    
    def validar_configuracion(self):
        """
        Revisa que el autómata esté bien configurado.
        - Que el estado inicial exista
        - Que los estados finales existan
        - Que haya transiciones para todos los símbolos de cada estado
        """
        errores = []
        
        if self.estado_inicial not in self.estados:
            errores.append(f"Estado inicial '{self.estado_inicial}' no existe en la lista de estados")
        
        for final in self.estados_finales:
            if final not in self.estados:
                errores.append(f"Estado final '{final}' no existe en la lista de estados")
        
        for estado in self.estados:
            if estado not in self.transiciones:
                errores.append(f"No hay transiciones definidas para el estado '{estado}'")
            else:
                for simbolo in self.alfabeto:
                    if simbolo not in self.transiciones[estado]:
                        errores.append(f"Falta transición para símbolo '{simbolo}' en estado '{estado}'")
                    elif self.transiciones[estado][simbolo] not in self.estados:
                        errores.append(f"Estado destino '{self.transiciones[estado][simbolo]}' no existe para transición desde '{estado}' con '{simbolo}'")
        
        if errores:
            print("Errores en la configuración:")
            for error in errores:
                print(f"  - {error}")
            return False
        
        return True
    
    def es_estado_final(self, estado):
        """Devuelve True si el estado está en la lista de finales"""
        return estado in self.estados_finales
    
    def procesar_cadena(self, cadena):
        """
        Procesa una cadena símbolo por símbolo.
        Devuelve:
        - Si fue aceptada o rechazada
        - El camino de estados recorridos
        - Las transiciones usadas
        - Algún error si ocurre
        """
        estado_actual = self.estado_inicial
        camino = [estado_actual]
        transiciones_desc = []
        
        for simbolo in cadena:
            if simbolo not in self.alfabeto:
                return False, camino, transiciones_desc, f"Símbolo '{simbolo}' no válido"
            
            if (estado_actual not in self.transiciones or 
                simbolo not in self.transiciones[estado_actual]):
                return False, camino, transiciones_desc, f"No hay transición definida para '{simbolo}' en estado '{estado_actual}'"
            
            estado_siguiente = self.transiciones[estado_actual][simbolo]
            transiciones_desc.append(f"{estado_actual} --{simbolo}--> {estado_siguiente}")
            estado_actual = estado_siguiente
            camino.append(estado_actual)
        
        return self.es_estado_final(estado_actual), camino, transiciones_desc, ""
    
    def procesar_archivo_cadenas(self, archivo_cadenas):
        """
        Procesa varias cadenas desde un archivo.
        Imprime el resultado de cada cadena: aceptada o rechazada.
        """
        try:
            with open(archivo_cadenas, 'r', encoding='utf-8') as f:
                cadenas = [line.strip() for line in f if line.strip()]
            
            print("RESULTADOS DEL AFD ")
            print(f"Estados: {', '.join(self.estados)}")
            print(f"Alfabeto: {', '.join(self.alfabeto)}")
            print(f"Estado inicial: {self.estado_inicial}")
            print(f"Estados finales: {', '.join(self.estados_finales)}")
            print("-" * 50)
            
            for cadena in cadenas:
                resultado, camino, transiciones, error = self.procesar_cadena(cadena)
                
                print(f"\nCadena: '{cadena}'")
                print(f"Camino: {' -> '.join(camino)}")
                
                if transiciones:
                    print(f"Transiciones: {', '.join(transiciones)}")
                
                if error:
                    print(f"ERROR: {error}")
                    print("RESULTADO: RECHAZADA")
                elif resultado:
                    print("RESULTADO: ACEPTADA")
                else:
                    print("RESULTADO: RECHAZADA")
                    
                
                    
        except FileNotFoundError:
            print(f"Error: No se encontró el archivo {archivo_cadenas}")
        except Exception as e:
            print(f"Error al procesar cadenas: {e}")

def main():
    # Creamos el AFD
    afd = AFD()
    
    # Cargamos la configuración desde el archivo Conf.txt
    if afd.cargar_configuracion("Conf.txt"):
        # Procesamos las cadenas desde el archivo que tenemos que es Cadenas.txt
        afd.procesar_archivo_cadenas("Cadenas.txt")

if __name__ == "__main__":
    main()

